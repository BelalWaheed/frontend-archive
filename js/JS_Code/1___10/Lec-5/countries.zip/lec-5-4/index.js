var egy = document.querySelectorAll(".bola");
function displayDiv(x) {
  egy[x].style.display = "block";
  for (var i = 0; i < egy.length; i++) {
    if (i != x) {
      egy[i].style.display = "none";
    }
  }
}
function removee() {
  for (var i = 0; i < egy.length; i++) {
    egy[i].style.display = "none";
  }
}
